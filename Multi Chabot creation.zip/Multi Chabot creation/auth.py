from fastapi import FastAPI, Depends, HTTPException, status
from pydantic import BaseModel
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
import bcrypt
from typing import Optional
import json
from fastapi.responses import JSONResponse

# FastAPI app instance
app = FastAPI()

# OAuth2PasswordBearer is used for token-based authentication, here it's just for form-based login
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

# Simple in-memory database (for demo purposes)
db = {}

# Pydantic models for data validation
class User(BaseModel):
    username: str
    password: str

class UserInDB(User):
    hashed_password: str

# Function to hash passwords
def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

# Function to verify password
def verify_password(plain_password: str, hashed_password: str) -> bool:
    return bcrypt.checkpw(plain_password.encode('utf-8'), hashed_password.encode('utf-8'))

# Route for user signup
@app.post("/signup", response_model=User)
async def signup(user: User):
    if user.username in db:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="User already exists")
    hashed_password = hash_password(user.password)
    db[user.username] = UserInDB(username=user.username, hashed_password=hashed_password, password=user.password)
    return user

# Route for user login (authentication)
@app.post("/token")
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    user = db.get(form_data.username)
    if not user or not verify_password(form_data.password, user.hashed_password):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
    return {"access_token": form_data.username, "token_type": "bearer"}

# Route to check if the user is authenticated
@app.get("/users/me")
async def read_users_me(token: str = Depends(oauth2_scheme)):
    user = db.get(token)
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authenticated")
    return {"username": user.username}
