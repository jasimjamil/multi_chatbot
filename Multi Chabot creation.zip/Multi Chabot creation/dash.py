import streamlit as st
from langchain.chains import ConversationalRetrievalChain
from langchain.vectorstores import FAISS
from langchain.embeddings import OpenAIEmbeddings
from langchain.chat_models import ChatOpenAI
from PyPDF2 import PdfReader
from langchain.document_loaders import PyPDFLoader
from langchain.text_splitter import CharacterTextSplitter
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain_groq import ChatGroq
from langchain.memory import ConversationBufferMemory
from langchain.prompts import PromptTemplate
import os

# Set API keys
os.environ['GROQ_API_KEY'] = "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"
os.environ['GOOGLE_API_KEY'] = 'AIzaSyA0S7F21ExbBnR06YXkEi7aj94nWP5kJho'

# st.set_page_config(page_title="Chatbot Dashboard", page_icon="🤖", layout="wide")
# Initialize session state
if "chatbots" not in st.session_state:
    st.session_state["chatbots"] = {}

if "current_chatbot" not in st.session_state:
    st.session_state["current_chatbot"] = None

# Helper function to create a chatbot
def create_chatbot(name, description, pdf_file):
    text = ""
    for pdf in pdf_file:
        pdf_reader = PdfReader(pdf)
        for page in pdf_reader.pages:
            text += page.extract_text()

    # Split text into chunks
    text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=50)
    docs = text_splitter.split_text(text)
    
    # Generate embeddings and save in FAISS vector store
    embeddings = GoogleGenerativeAIEmbeddings(model="models/embedding-001")
    vectorstore = FAISS.from_texts(docs, embeddings)
    vectorstore.save_local(f"chatbot_{name}_vectorstore")

    # Define the prompt template with placeholders for name and description
    prompt_template = f"""
You are {name}, a highly intelligent and interactive chatbot designed to assist users effectively. 
Your role is to be {description}. You are approachable, friendly, and always willing to help.

When someone asks about your name, respond with:
"My name is {name}."

When someone asks about your role or expertise, respond with:
"I am {description}."

You have been trained with the knowledge from the uploaded documents, and you excel at providing precise and helpful responses.

Always engage in a friendly tone and guide users through their queries with enthusiasm and expertise.
    
Document Context: {{context}}
Question from user: {{question}}

If the user asks for your name, always respond with "My name is {name}".
If the user asks about your expertise, always respond with "I am an expert in {description}".
""" 
    prompt = PromptTemplate(template=prompt_template, input_variables=["context", "question"])

    # Create a conversational chain with memory and retriever
    chat_model = ChatGroq(model="mixtral-8x7b-32768")
    memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)

    qa_chain = ConversationalRetrievalChain.from_llm(
        llm=chat_model,
        retriever=vectorstore.as_retriever(),
        memory=memory,
        combine_docs_chain_kwargs={"prompt": prompt},
    )
    
    # Save chatbot metadata
    st.session_state["chatbots"][name] = {
        "description": description,
        "vectorstore_path": f"chatbot_{name}_vectorstore",
        "qa_chain": qa_chain,
        "name": name,  # Save the name and description in session state
        "description": description,
    }

# Dashboard UI with custom CSS for enhanced visuals
st.set_page_config(page_title="Chatbot Dashboard", page_icon="🤖", layout="wide")

# Add custom CSS for styling
st.markdown("""<style>
    .stButton button {
        background-color: #FF6347;
        color: white;
        font-size: 18px;
        font-weight: bold;
        border-radius: 8px;
        height: 50px;
        width: 100%;
    }
    .stButton button:hover {
        background-color: #FF4500;
    }
    .stTextInput input, .stTextArea textarea {
        font-size: 18px;
        padding: 12px;
        border-radius: 8px;
    }
    .stSelectbox select {
        font-size: 18px;
        padding: 10px;
        border-radius: 8px;
    }
    .stMarkdown {
        font-size: 22px;
        color: #333333;
        font-weight: 600;
    }
</style>""", unsafe_allow_html=True)

# Title and Sidebar customization
st.title("💬 **Chatbot Dashboard**")
st.sidebar.title("🌟 **Menu**")

# Sidebar options
option = st.sidebar.radio("Select an Option", ["Dashboard", "Create Bot", "Chat with Bot"])

# Dashboard section
if option == "Dashboard":
    st.header("🌟 Your Chatbots")
    if st.session_state["chatbots"]:
        for name, details in st.session_state["chatbots"].items():
            st.subheader(f"🧑‍💼 {name}")
            st.markdown(f"**Description**: {details['description']}")
    else:
        st.write("🚨 No chatbots created yet. Please create one from the sidebar.")

# Create Bot section
elif option == "Create Bot":
    st.header("🤖 **Create a New Chatbot**")
    
    chatbot_name = st.text_input("Chatbot Name", max_chars=50, placeholder="Enter a unique name")
    chatbot_description = st.text_area("Chatbot Description", placeholder="Describe your chatbot's purpose")
    chatbot_pdf = st.file_uploader("Upload PDF File(s)", type=["pdf"], accept_multiple_files=True)
    
    if st.button("✨ **Create Chatbot**", use_container_width=True):
        if chatbot_name and chatbot_description and chatbot_pdf:
            with st.spinner("Creating your chatbot..."):
                create_chatbot(chatbot_name, chatbot_description, chatbot_pdf)
            st.success(f"🎉 Chatbot '{chatbot_name}' created successfully!")
        else:
            st.error("⚠️ Please fill in all fields and upload at least one PDF.")

# Chat with Bot section
elif option == "Chat with Bot":
    st.header("💬 **Chat with Your Chatbot**")
    
    if st.session_state["chatbots"]:
        chatbot_name = st.selectbox("Select a Chatbot", list(st.session_state["chatbots"].keys()))
        if chatbot_name:
            st.session_state["current_chatbot"] = chatbot_name
            user_query = st.text_input("Ask a question:", placeholder="Type your question here...", label_visibility="collapsed")
            
            if st.button("📬 Send", use_container_width=True):
                if user_query:
                    qa_chain = st.session_state["chatbots"][chatbot_name]["qa_chain"]
                    name = st.session_state["chatbots"][chatbot_name]["name"]
                    description = st.session_state["chatbots"][chatbot_name]["description"]
                    
                    # Create a single input string for the question and context
                    context = ""  # You can add relevant context if needed
                    input_string = f"Document Context: {context}\nQuestion: {user_query}"
                    
                    # Call the qa_chain with the combined input
                    result = qa_chain({"question": input_string})  # Adjusted to use a single input key
                    
                    st.write(f"**Bot:** {result['answer']}")
                else:
                    st.error("⚠️ Please enter a question.")
    else:
        st.write("🚨 No chatbots available. Please create one first.")
