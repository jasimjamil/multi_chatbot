import streamlit as st
import requests
import os
from PyPDF2 import PdfReader
from langchain.chains import ConversationalRetrievalChain
from langchain.vectorstores import FAISS
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain_groq import ChatGroq
from langchain.text_splitter import CharacterTextSplitter
from langchain.memory import ConversationBufferMemory
from langchain.prompts import PromptTemplate

# Set API keys
os.environ['GROQ_API_KEY'] = "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"
os.environ['GOOGLE_API_KEY'] = 'AIzaSyA0S7F21ExbBnR06YXkEi7aj94nWP5kJho'

st.set_page_config(page_title="Chatbot Dashboard", page_icon="🤖", layout="wide")

st.markdown("""<style>
    .stButton button {
        background-color: #FF6347;
        color: white;
        font-size: 18px;
        font-weight: bold;
        border-radius: 8px;
        height: 50px;
        width: 100%;
    }
    .stButton button:hover {
        background-color: #FF4500;
    }
    .stTextInput input, .stTextArea textarea {
        font-size: 18px;
        padding: 12px;
        border-radius: 8px;
    }
    .stSelectbox select {
        font-size: 18px;
        padding: 10px;
        border-radius: 8px;
    }
    .stMarkdown {
        font-size: 22px;
        color: #333333;
        font-weight: 600;
    }
</style>""", unsafe_allow_html=True)


if "chatbots" not in st.session_state:
    st.session_state["chatbots"] = {}
if "authenticated" not in st.session_state:
    st.session_state["authenticated"] = False


def create_chatbot(name, description, pdf_files):
    text = ""
    for pdf in pdf_files:
        pdf_reader = PdfReader(pdf)
        for page in pdf_reader.pages:
            text += page.extract_text()

   
    text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=50)
    docs = text_splitter.split_text(text)
    
    
    embeddings = GoogleGenerativeAIEmbeddings(model="models/embedding-001")
    vectorstore = FAISS.from_texts(docs, embeddings)
    vectorstore.save_local(f"chatbot_{name}_vectorstore")

    prompt_template = f"""
    You are {name}, a highly intelligent and interactive chatbot designed to assist users effectively. 
    Your role is to be {description}. You are approachable, friendly, and always willing to help.

    When someone asks about your name, respond with:
    "My name is {name}. How can I assist you today? 😊"
    Example: If a user asks, 'What is your name?', you would respond with:
    "My name is {name}. How can I assist you today? 😊"

    
    Always make sure to respond in a friendly, conversational manner that makes the user feel at ease. You are here to help, and your goal is to make the user feel heard and supported.

    When responding to any user question, ensure that you provide a clear, accurate, and helpful answer. If you're unsure, let them know that you'll do your best to help, and encourage them to ask for clarification if needed. 

    Document Context: {{context}}
    Question from user: {{question}}
"""
    prompt = PromptTemplate(template=prompt_template, input_variables=["context", "question"])

    
    chat_model = ChatGroq(model="mixtral-8x7b-32768")
    memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)
    qa_chain = ConversationalRetrievalChain.from_llm(
        llm=chat_model,
        retriever=vectorstore.as_retriever(),
        memory=memory,
        combine_docs_chain_kwargs={"prompt": prompt},
    )

    st.session_state["chatbots"][name] = {
        "description": description,
        "vectorstore_path": f"chatbot_{name}_vectorstore",
        "qa_chain": qa_chain
    }

def signup(username, password):
    response = requests.post("http://127.0.0.1:8000/signup", json={"username": username, "password": password})
    if response.status_code == 200:
        st.success("Signup successful! You can now log in.")
    else:
        st.error("Signup failed. Please try again.")

def login(username, password):
    response = requests.post("http://127.0.0.1:8000/token", data={"username": username, "password": password})
    if response.status_code == 200:
        st.session_state["authenticated"] = True
        st.session_state["token"] = response.json()["access_token"]
        st.success(f"Welcome back, {username}!")
        st.experimental_rerun()
    else:
        st.error("Invalid credentials. Please try again.")

if not st.session_state["authenticated"]:
    st.title("Welcome to the Chatbot Dashboard")
    auth_option = st.radio("Select an option:", ["Sign Up", "Log In"])
    
    username = st.text_input("Username")
    password = st.text_input("Password", type="password")

    if auth_option == "Sign Up":
        password_confirm = st.text_input("Confirm Password", type="password")
        if st.button("Sign Up"):
            if password == password_confirm:
                signup(username, password)
            else:
                st.error("Passwords do not match!")
    elif auth_option == "Log In":
        if st.button("Log In"):
            login(username, password)
else:
    # Dashboard
    st.sidebar.title("Menu")
    option = st.sidebar.radio("Navigate to:", ["Dashboard", "Create Bot", "Chat with Bot"])

    if option == "Dashboard":
        st.header("Your Chatbots")
        if st.session_state["chatbots"]:
            for name, details in st.session_state["chatbots"].items():
                st.subheader(name)
                st.write(f"Description: {details['description']}")
        else:
            st.write("No chatbots created yet.")

    elif option == "Create Bot":
        st.header("Create a New Chatbot")
        name = st.text_input("Chatbot Name")
        description = st.text_area("Chatbot Description")
        pdf_files = st.file_uploader("Upload PDF Files", type=["pdf"], accept_multiple_files=True)
        
        if st.button("Create Chatbot"):
            if name and description and pdf_files:
                create_chatbot(name, description, pdf_files)
                st.success(f"Chatbot '{name}' created successfully!")
            else:
                st.error("All fields are required.")

    elif option == "Chat with Bot":
        st.header("Chat with Your Chatbot")
        if st.session_state["chatbots"]:
            chatbot_name = st.selectbox("Select a chatbot:", list(st.session_state["chatbots"].keys()))
            if chatbot_name:
                query = st.text_input("Ask a question:")
                if st.button("Send"):
                    qa_chain = st.session_state["chatbots"][chatbot_name]["qa_chain"]
                    result = qa_chain({"question": query})
                    st.write(f"**{chatbot_name}:** {result['answer']}")
        else:
            st.write("No chatbots available. Create one first.")
